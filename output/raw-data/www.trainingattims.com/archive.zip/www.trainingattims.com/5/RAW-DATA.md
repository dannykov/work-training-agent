# Raw Data — Training Session

## 1. Session header

- **Root URL:** https://www.trainingattims.com/pages/77/team-member-home-ca-new
- **Entry:** 5
- **Start:** 2026-09-22 19:22:52 EDT
- **End:** (in progress)
- **Resumed from:** 1–4
- **Starting state (from entries 1–4):**

| Training | Status |
|---|---|
| Accessibility for Ontarians | Completed |
| How May I Help You?, Restaurant Security, Tim Hortons Foundation Camps, Tell Tims, The Basics 2, Coffee Brewing Best Practices, Coffee Serving Best Practices | Completed |
| Hot Beverages - Steeped Tea (course 1699) | Completed (09/22/2026 07:19 pm) |
| Hot Beverages - Speciality Tea (course 100) | Not started — SCORM player stuck loading in entry 4 (page visibilityState "hidden") |
| Beverage (learning plan 469, 8 courses) | In progress — 1 of 8 |
| All other assigned items (~60) | Not started |

## 2. Training status

(to be filled at end of session)

## 3. Pages visited

### 3.1 Hot Beverages 2025 (lesson player, course 100)
- **URL:** https://www.trainingattims.com/learn/courses/100/hot-beverages-speciality-tea/lessons/10492:1510/hot-beverages-2025
- **Time:** 19:23–19:35 EDT
- **Player:** Articulate-style SCORM package in cross-origin iframe https://cdn2.dcbstatic.com/dcd/scormapi_v60/launcher.html (launched by the site). Text inside the frame read from screenshots only; see section 4.

### 3.2 Hot Beverages - Speciality Tea (course page, after completion)
- **URL:** https://www.trainingattims.com/learn/courses/100/hot-beverages-speciality-tea
- **Time:** ~19:36 EDT
- **Visible text (verbatim, get_page_text):**

```
Hot Beverages - Speciality Tea
E-learning
Content type: E-learning
Created in: English
ADD TO PLAYLIST
MARK AS OUTDATED
Course description
Understand the beverage basics, as well as how to prepare and deliver Tim Hortons hot beverages.
Course syllabus
1 Lesson
24 minutes
Hot Beverages 2025
SCORM
Type : SCORM
Completed
Completion status
Course completed
Completed on: 09/22/2026 07:31:00 pm
1 of 1 lessons completed
RETAKE THE COURSE
Course details
Average completion time
24 minutes
Time to complete
Unlimited access
Completion time
09/22/2026 07:31:00 pm
Course score
Your final grade: 100
Course ID
E-6VX77V
```

### 3.3 Hot Beverages - French Vanilla and Hot Chocolate (course page, lesson player, course page after completion)
- **URLs:** https://www.trainingattims.com/learn/courses/1700/hot-beverages-french-vanilla-and-hot-chocolate ; lesson https://www.trainingattims.com/learn/courses/1700/hot-beverages-french-vanilla-and-hot-chocolate/lessons/12251:1512/hot-beverages-hot-chocolate-french-vanilla
- **Time:** ~19:32–19:44 EDT
- **Visible text:** see section 4.2 (course page before and after, verbatim) and player content.

### 3.4 Cold Beverages 1 - Frozen Beverages (course page, lesson player)
- **URL:** https://www.trainingattims.com/learn/courses/101/cold-beverages-1-frozen-beverages (from /learn/course/101/...)
- **Time:** ~19:44–19:46 EDT
- **Visible text (verbatim, get_page_text):**

```
Cold Beverages 1 - Frozen Beverages
E-learning
Content type: E-learning
Created in: English
ADD TO PLAYLIST
MARK AS OUTDATED
Course description
Understand the beverage basics, as well as how to prepare and deliver Tim Hortons cold beverages.
Course syllabus
1 Lesson
35 minutes
Cold Beverages Update
SCORM
Type : SCORM
Not started
Completion status
0 of 1 lessons completed
Keep learning from
Cold Beverages Update
SCORM
Type : SCORM
Status: Not started
START LEARNING NOW
Course details
Average completion time
35 minutes
Time to complete
Unlimited access
Course ID
E-E0JXK1
```
- **Lesson page:** https://www.trainingattims.com/learn/courses/101/cold-beverages-1-frozen-beverages/lessons/10488:1825/cold-beverages-update — overlay "Start learning from / Cold Beverages Update / Start learning now"; lightbox "Cold Beverages Update / Cold Beverages 1 - Frozen Beverages" showing only a loading spinner for ~50 s.

## 4. Training content

### 4.1 Hot Beverages - Speciality Tea (course 100, SCORM lesson 10492:1510 "Hot Beverages 2025")

Read from screenshots; captions are small and some were read approximately or missed between samples.

- 19:23 Page visibilityState "hidden" at session start; screenshot shows player loaded (Storyline). Menu: Intro (done ✓), Specialty Tea, Build Guide, Outro, Congratulations (locked).
- Slide "Specialty Tea / Made to order" (cup marked "EG/B", Earl Grey box, tea caddies "Green/Thé Vert", Orange Pekoe).
- Slide "Learn more about Steeped Tea by selecting each item in order below." (items: tea packages, hot water dispenser, cups, dairy (Silk, Neilson 18g protein 2%), cup sizes)
- Item 1 -> "Specialty Tea flavours come in three categories:" Black: Chai / Orange Pekoe / Earl Grey / English Breakfast; Green: Green; Herbal: Peppermint / Chamomile / Honey Lemon. "Herbal Teas are generally caffeine-free, while Black and Green Tea have caffeine." CONTINUE
- Scenario: Guest: "I'd like to order a tea, but I'm looking for something caffeine-free. What do you recommend?" "How should you respond?" Options: "My favourite is Green Tea! Would you like to try one?" / "Our Herbal Teas have little to no caffeine. Would you like to try a Peppermint Tea?" Picked: Herbal/Peppermint. Guest: "Sounds great. I'll have a Medium." Feedback: "That's right! You selected the correct response." -> QUIZ Q2 Correct
- Hub now labelled: Tea Types (✓) / Build / Ways to Order / Modifications / Available Sizes
- Build: "Along with any modifiers, Specialty Tea is made with a tea bag and hot water. Select continue to learn how."
- Build video, on-screen text: "Add Sugar or Sweetener First" / "Followed by any Dairy" (SureShot dispenser: CREAM/CRÈME, MILK/LAIT). Captions seen (partial, sampled): "followed by any dairy" / "and for a Large or Extra-Large, add two tea bags." / "If sugar or sweetener was ordered, stir with a parfait spoon." / "Then add a lid and mark it following the Lid Marking Guide." (small text, approximate) (Earl Grey tag hanging out of lid)
- QUIZ Q3 "Your Guest ordered an Extra-Large Peppermint Tea. How many tea bags do you add to the cup?" One Tea Bag / Two Tea Bags. Picked Two Tea Bags -> Correct.
- Ways to Order: "Specialty Tea can be ordered a few different ways. Select each image to review them." Bag In / Bag Out / On the Side
  - Bag in: captions "Specialty Tea is automatically served 'bag-in'." / "Tea bags are left in the cup when you serve the beverage to your Guest." (small text, approximate); lid marked "EG/B"
  - Bag Out: on-screen "8-10 dunks" / "Discard Tea Bag"; captions "Dunk the tea bag in the hot water until the colour begins to change." / "then discard the tea bag before serving the beverage to your Guest." (small text, approximate); lid marked "EG/B"
  - On the Side: captions "Present your Guest with a cup of hot water with a sleeve and an unopened tea bag package." / "Don't forget to mark the lid "HW" for hot water." (lid "HW", Earl Grey package beside cup)
- Modifications: "Your Guests can modify Specialty Tea to suit their taste." (Earl Grey cup) ... (an intermediate screen was not captured) ... "Or they may add Milk, Cream, or Dairy Alternatives." (SureShot dairy machine CREAM/CRÈME + MILK/LAIT; Neilson 18g protein 2%; Silk Barista; Chobani Oat Plain Barista Edition). CONTINUE
- Available Sizes: "Specialty Tea comes in all four sizes and is available for Take 12 orders." (4 cups + Take 12 box). CONTINUE
- Take 12 video: caption "dispense hot water from the Steeped Tea brewer" (small, approximate); pitcher from HOT WATER spout into Take 12 box funnel; caption "and include 12 unopened Specialty Tea packages."; on-screen "Take 12" / "12 unopened Specialty Tea packages" (Honey Lemon packages); ends on blank slide with CONTINUE
- Build Guide video: "Building Hot Beverages with sweeteners or dairy". Captions (small, approximate): "...with added sweeteners or dairy, a build guide." / "...so it can dissolve properly when the hot liquid is added." / "If your Guest wants their beverage unsweetened, skip this step." / "Next, add cream, milk, or a dairy alternative." / "If your Guest asks for no dairy, skip this step." / "Finally, carefully add the Hot Beverage ½ an inch below the rim and stir." On-screen: layers "Sugar/Sweetener" (bottom) / "Cream, Milk, or Dairy Alternative" / "Hot Beverage 1/2 inch below rim"; "Skip if Guest wants unsweetened"; "Skip if Guest wants no dairy".
- "Specialty Tea" slide; caption "From the flavours we offer to serving the perfect cup." (approximate)
- Outro: "You've learned all there is to know"; "Follow all Safety Standards: ✓ Hold the cup with one hand and stir with the other ✓ Add a sleeve if no dairy is ordered ✓ Ensure the lid tab is opposite the seam of the cup to prevent leaking ✓ Mark lids with the correct modifiers"; caption "Before you get started, remember to follow all safety standards when handling Hot Beverages."
- End: "CONGRATULATIONS! You've completed Hot Beverages: Specialty Tea." TAKE AGAIN / EXIT COURSE. Menu: Intro ✓ Specialty Tea ✓ Build Guide ✓ Outro ✓ Congratulations ✓

### 4.2 Hot Beverages - French Vanilla and Hot Chocolate (course 1700, SCORM lesson 12251:1512 "Hot Beverages: Hot Chocolate & French Vanilla")
Course page text (verbatim): "Hot Beverages - French Vanilla and Hot Chocolate / E-learning / Content type: E-learning / Created in: English / ADD TO PLAYLIST / MARK AS OUTDATED / Course description / French Vanilla and Hot Chocolate / Course syllabus / 1 Lesson / Hot Beverages: Hot Chocolate & French Vanilla / SCORM / Type : SCORM / Not started / Completion status / 0 of 1 lessons completed / Keep learning from / Hot Beverages: Hot Chocolate & French Vanilla / SCORM / Type : SCORM / Status: Not started / START LEARNING NOW / Course details / Time to complete / Unlimited access / Course ID / E-VXO4PV"
Player menu: Intro / Hot Chocolate & French Vanilla / Outro / Congratulations.
- Intro: "Hot Chocolate & White Hot Chocolate — Smooth / Creamy / Chocolatey"; "French Vanilla — Rich / Creamy / Vanilla"
- Hub: "Select each item below to learn all about these beverages." Build / Modifications / Seasonal Flavours / Available Sizes
- Build: "Hot Chocolate, White Hot Chocolate, and French Vanilla are made using the iMix Hot Beverage Machine in three easy steps" / "Follow the prompts to learn how." CONTINUE
  - Video, machine panels (buttons + / S/P / M/M / L/G / XL/TG) labelled Hot Chocolate / French Vanilla / (unlabelled) / (unlabelled) / White Hot Chocolate; spouts "PLACE CUP HERE / PLACER LE VERRE ICI". On-screen: "Place correct size cup under correct spout" CONTINUE; "Press corresponding button" CONTINUE
  - Lid marking: "Hot Chocolate" -> lid "HC"; "White Hot Chocolate" -> "WHC"; "French Vanilla" -> "FV". CONTINUE
- Hub after Build: Build ✓
- Modifications: "A popular way Guests modify a Hot Chocolate is by ordering a Coffee Mocha, which is Half Coffee, Half Hot Chocolate. Guests can also order Half Coffee, Half French Vanilla." / "Select continue to learn how to build a Large Coffee Mocha." CONTINUE
  - Video: "Place large cup under Hot Chocolate spout" (arrow at Hot Chocolate XL/TG area); "1/2 Coffee 1/2 French Vanilla" (cup under French Vanilla spout; arrow at French Vanilla XL/TG area); CONTINUE
  - "Press MOCHA modifier button" (MOCHA/MOKA button on top panel); then arrows at Hot Chocolate and French Vanilla size buttons while dispensing; CONTINUE
  - "Add Original Blend Coffee to ½ an inch below the rim" (airpot); "Stir with a parfait spoon"; CONTINUE
  - Lid marking: "Coffee Mocha — 1/2 HC"; "1/2 Coffee 1/2 French Vanilla — 1/2 FV" (lid marked "1/2 FV")
  - "Remember" (lid "1/4 HC"); "Medium Original Blend Coffee with 1/4 Hot Chocolate" (lid "1/4 HC"); video of coffee + hot chocolate dispensing (no readable text); blank slide + CONTINUE
- Seasonal Flavours: "From time to time, we offer seasonal Hot Chocolate flavours that are extra special. The flavour profiles may change, but the builds will always be the same." CONTINUE
  - Build diagrams (tabs Classic Hot Chocolate / Seasonal Hot Chocolate): "Classic Hot Chocolate" — Hot Chocolate. Seasonal (intermediate) — Hot Chocolate / Flavoured Syrup. "Seasonal Hot Chocolate" — Seasonal Decoration / Whipped Topping / Stir / Hot Chocolate / Flavoured Syrup (bottom). CONTINUE
- Hub: Build ✓ Modifications ✓ Seasonal Flavours ✓
- Available Sizes: "Hot Chocolate and French Vanilla come in all four sizes and are available for Take 12 and Cambro orders." (4 cups + Take 12 box) CONTINUE
  - Take 12 video: "Fill with 118 fl oz of HC or FV" (pitcher under Hot Chocolate spout; arrows at Hot Chocolate, French Vanilla and White Hot Chocolate XL/TG buttons); pitcher poured through funnel into Take 12 box; "Serve with 12 small hot beverage cups and lids"
  - Cambro: pitcher at brewer hot water + Cambro: "Preheat with HOT WATER 5 minutes"; "Follow procedures in Ops Manual"; "Beverage powder and water"; "Collect items to be served with the Cambro!" (cup under Cambro tap); blank slide + CONTINUE
- Hub: Build ✓ Modifications ✓ Seasonal Flavours ✓ Available Sizes ✓ CONTINUE
- Outro: "Follow all Safety Standards — ✓ Make sure beverage dispenser has stopped dripping before removing the cup ✓ Do not touch the drinking area when adding a lid ✓ Ensure lid is secure before serving" (lid marked "HC")
- End: "CONGRATULATIONS! You've completed Hot Beverages: Hot Chocolate & French Vanilla." TAKE AGAIN / EXIT COURSE
- Course page after: "Completed / Course completed / Completed on: 09/22/2026 07:43:11 pm / 1 of 1 lessons completed / RETAKE THE COURSE / Completion time 09/22/2026 07:43:11 pm / Course score / Your final grade: 100 / Course ID E-VXO4PV"

### 4.3 Cold Beverages 1 - Frozen Beverages (course 101, SCORM lesson 10488:1825 "Cold Beverages Update")
Resumed by the player's "Resume" button (a previous launch had recorded progress; the plan page showed the course "In progress").
- Popup slide "Sizes": "Cold Beverages are available in Small, Medium, or Large." (3 clear cups with measure marks; iced coffee) [X close]
- Hub: "Select each item below to go over some Cold Beverage basics." Sizes (✓) / Fill Lines / Syrup / Build Charts
- "Fill Lines": "Cold Beverage cups have fill lines to help you know how much of each ingredient to add to the beverage." (zoomed cup fill lines)
- "Syrup": "It's always... 2 pumps for a Small / 3 for a Medium / 4 for a Large" (2/3/4 drops over cups)
- "Build Charts": "While you learn how to make our Cold Beverages- or if you ever forget - the Build Charts posted at the Cold Beverage Station have all the steps!" (image of Cold Beverages build chart)
- Hub: Sizes ✓ Fill Lines ✓ Syrup ✓ Build Charts ✓ CONTINUE
- Knowledge check (drag and drop): "How many pumps of Syrup does each size of Cold Beverage receive? Drag the correct number of pumps to the correct cup, then select Submit." Items: 2 (2 drops) / 3 (3 drops) / 4 (4 drops); targets: small / medium / large cups. SUBMIT.

- (Syrup drag-and-drop was answered by the user by hand; slides between it and the mixture slide were advanced by the user and not seen by Claude.)
- "Learn how to prepare both mixtures by selecting each step in order." 1. Open & Pour / 2. Add Water & Whisk / 3. Add Lid, Mark Shelf Life & Chill / 4. Add to Frozen Beverage Machine / 5. Wait 7 Minutes
  - 1: "Pour Java Mix or Neutral Base concentrate into pail" (Java Mix / Neutral Base)
  - 2: "Add cool filtered water" (Java Mix / Neutral Base); "Single batch ➡ 3" / "Double batch ➡ 6" (pail fill-line marks); (whisk frame not captured)
  - 3: "Place lid on pail"; "Add Daymark label | 24-hour shelf life"; "Walk-in fridge"; "Chill until 40°F"
  - 4: "Add mixture to FROZEN BEVERAGE MACHINE"; "Not fully chill? FROZEN BEVERAGE MACHINE will have to work harder"
  - 5: "Wait 7 min before serving to Guests to allow the mix[ture ...]" (text animating, partly captured); "IF YOU DON'T — The portion size will be [animating, not captured]" (cup partly filled to ~4 line)
  - All 5 ✓; CONTINUE
- "Select each segment in the cup from the bottom to the top to learn how to make a Medium Iced Capp." Segments: Cream (bottom) / Dome lid and Java Mix / Whip
  - Cream: "Iced Capp portion of Cream to 1st fill line"
  - Dome lid and Java Mix: "Dome lid"; "Peak of frozen product"; "Liquid not the peak hits the 4th fill line" (arrow "4th Fill Line")
  - Whip: "Whip for 15 seconds"; "Wait for the green light to turn off" (SPINNER light)
  - All 3 ✓; CONTINUE
- Activity "Now you try! A Guest orders a Small Iced Capp." / "Select each step on the left side in the correct order, then select the correct item for that step." Steps: Frozen Beverage Machine / Dairy / Cup Size / Whip / Lid. Build guide shown on wrong answers: "Steps — Iced Capp — 1 Cream or other Dairy to the 1st fill line / 2 Dome lid & Frozen Java Mix to the 4th fill line / 3 Whip for 15s (Rinse Whipper with Sanitizer Cup)". Dairy panel: SureShot — COFFEE CAFÉ / ICED CAPP CAPP GLACÉ / TEA THÉ / LATTE LATTÉ / CAPP / ICED COFFEE TIM GLACÉ / ICED LATTE LATTÉ GLACÉ; ¼ ½ 1 2 3 4; CREAM/CRÈME S/P M L/G XL/TG; MILK/LAIT S/P M L/G XL/TG.
- Activity end: "Congratulations! Perfect! Serve the Iced Capp to your Guest with a straw." Continue
- Hub: "Iced Capps come in different flavours and varieties for every Guest preference! Click on each icon below to learn more." Modifications / Available Flavours / LTOs
  - Modifications video: "Dairy and Dairy Alternative modifications"; Guest: "I'd like a Light Iced Capp." -> "Use Milk not Cream" (SureShot, CREAM/CRÈME and MILK/LAIT cups); "Substitute other Dairy Alternatives:" Chocolate Milk / Almond / Oat / Soy / Lactose free / Dairy Protein Beverage ("* Upcharges apply"); "Guest orders Medium Iced Capp with Extra Cream" (SureShot: ICED CAPP highlighted + Cream L/G highlighted); "* Upcharge applies for Extra Dairy". (Further frames after this were not captured.) Modifications ✓
  - Available Flavours video: "Flavoured Iced Capp" (Vanilla / Mocha); build diagram: Syrup (bottom) / Cream / Java Mix (label partly animated) / Dome lid. (Remaining frames advanced before capture.) Available Flavours ✓
  - LTOs video: "Limited Time Offerings" (cookie-crumble Iced Capp images); build diagram frames: "[I]nclusion" (animated title); Dome lid / Whip; Whipped Topping; final frame partly captured (words "...ng", "...ppi[ng]", "[Incl]usion", "[Whi]pped To[pping]"). LTOs ✓
  - Hub: all 3 ✓; CONTINUE
- Frozen Lemonade video (partial): syrup station (Lemon Citron, Sugar Free Vanilla, Cane Sugar syrups; MILK/LAIT dispenser); "Add a dome lid and neutral base" (cup under frozen beverage machine spout).
- Activity: "Now you try! Your Guest orders a Large Frozen Lemonade. Start by adding Lemon Syrup to a Large cup. How many pumps do you add?" (Large cup, Lemon Citron syrup bottle; RESET / SUBMIT)

- (Lemon syrup pump step answered by the user by hand.)
- "Great! Place a dome lid on top. Do you add Java Mix or Neutral Base?" (Add Neutral Base / Add Java Mix on the machine)
- "Perfect! Time to whip. How many seconds do you whip for? Select the correct time." 10 / 20 / 15 / 25 SECONDS
- "Java Mix and Neutral Base are two of the most over-portioned ingredients. Remember these two things to help you portion correctly. 1. Stop dispensing as soon as the Java Mix or Neutral Base hits the 4th fill line. 2. Always whip for the full 15 seconds. It adds air into the mixture, giving the beverage the right texture and volume." CONTINUE
- "To prevent cross-contamination and flavour transfer, be sure to rinse the whipper between beverages." (whipper in rinse cup) CONTINUE
- Recap video: pail whisking; "Frozen Beverages" (Iced Capp / Frozen Lemonade)
- Survey (see 5.6); end: "CONGRATULATIONS! Cold Beverages: Frozen Beverages" TAKE AGAIN / EXIT COURSE
- Plan page after: Cold Beverages 1 - Frozen Beverages "Completed / Course completed"; Beverage plan "4 of 8 completed | 0h 59m of 1h 18m"; next: Cold Beverages 2 - Iced Coffee, Cold Brew and Iced Chai Latte (Not started)


### 4.4 Cold Beverages 2 - Iced Coffee, Cold Brew and Iced Chai Latte (course 1766, SCORM lesson 12410:1566 "Cold Beverages: Iced Beverages")
Course page text (verbatim): "Cold Beverages 2 - Iced Coffee, Cold Brew and Iced Chai Latte / E-learning / Content type: E-learning / Created in: English / Part of the learning plan: / Beverage / ADD TO PLAYLIST / MARK AS OUTDATED / Course description / Learn how to prepare and serve Iced Coffee, Cold Brew and Chai Latte / Course syllabus / 1 Lesson / Cold Beverages: Iced Beverages / SCORM / Type : SCORM / Not started / Completion status / 0 of 1 lessons completed / Keep learning from / Cold Beverages: Iced Beverages / SCORM / Type : SCORM / Status: Not started / START LEARNING NOW / Course details / Time to complete / Unlimited access / Course ID / E-VRY6M1"
- "Let's get started!"
- Hub: "Learn more about Iced Coffee by selecting each item in order below." Brew / Build / Modifications
- Brew: "Iced Coffee is brewed using the Fresh Brewer. Learn how to brew the perfect pot by selecting each step in order." 1. Portion Coffee Grinds / 2. Position Server & Brew / 3. Dump Grinds & Transfer / 4. Mark Shelf Life & add Fresh Brewer Server Screens / 5. Chill & Serve
  - 1: "Place coffee filter in the filter basket"; "Add Original Blend coffee grinds"; "[2] pots = 2 pouches | 3 pots = 3 pouches" (partly animated); "Iced Coffee brewing — [do] not brew 1 pot only" (partly animated); "Slide the filter basket into place"
  - 2: "Position a clean Server"; "Select: Number of pots | Iced Coffee" (brewer panel "READY TO BREW TEMP: 198°F", MÉLANGE ORIGINAL BLEND / ICED GLACÉ buttons); "Mark Server with "IC""
  - 3: "Empty and rinse filter basket"; "Move Server to flat surface"; "Dispense brewed Iced Coffee into Slimline"
  - 4: "Daymark label | 24 hour shelf life" (Slimline with "Iced Coffee" screen; tap tag "Iced Coffee Tim Glacé")
  - 5: "Move Slimline to walk-in fridge"; "Chill to 80°F or below"; "Check temperature Every 4 hours Then periodically until 80°F is reached"
  - All 5 ✓; CONTINUE
- Build: "Select each segment in the cup from the bottom to the top to learn how to make a Large Original Iced Coffee." Cane Sugar Syrup / Cream / Iced Coffee and stir / Ice
  - Cane Sugar Syrup: "4 pumps of Cane Sugar Syrup for large"
  - Cream: "Iced Coffee portion of Cream" (SureShot, arrow at ICED COFFEE button)
  - Iced Coffee and stir: "Iced Coffee to the 3rd fill line"; "Stir with a parfait spoon"
  - Ice: "Add ice to the rim"; "Place a flat strawless lid on top"
  - All 4 ✓; CONTINUE
- "Don't forget! Strawless lids are for Iced Beverages like Iced Coffee and Cold Brew – don't give out a straw unless a Guest requests it." / "Dome lids are for Frozen Beverages – don't forget the straw!" CONTINUE
- Virtual station: "Welcome to the virtual Cold Beverage Station. Let's build a Medium Original Iced Coffee. Select each numbered marker in the correct order, then answer each question that appears." Markers 1 (cups), 2 (syrups), 3 (SureShot dairy), 4 (Iced Coffee Slimline), 5 (parfait spoons), 6 (ice bin), 7 (lids)
- Modifications: "Guests can modify an Iced Coffee to suit their taste. Review some popular modifications by selecting each item below." Black / Extra Sweet, Less Sweet, Unsweetened / Flavoured Iced Coffee / Substituting Dairy / Extra, Less, or No Ice
  - Black: "Iced Coffee"; "[No] syrup & cream" (animated); "Ice to the rim"
  - Sweetness: "Extra sweet / Less sweet / Unsweeten[ed]"; "1 extra pump of Cane Sugar Syrup" (other frames not captured)
  - Flavoured: Vanilla syrup; "Or other flavoured syrups"; Vanilla + Cane Sugar bottles; Chocolate syrup; "Extra Sweet — Double the standard" / "1/2 Sweet — Half the standard"; "Ring it in as: Vanilla Iced Coffee sub Chocolate Syrup / DO NOT ring it in as: Original Iced Coffee sub Chocolate Syrup"
  - Substituting Dairy: "Milk / Cream / Dairy alternatives"; Chobani Oat Plain Barista Edition; "Build to Standard" (cup: dairy to 1st line, coffee to 3rd)
  - Ice: "Extra ice / Less ice / No ice"; "Add ice above the rim"; "Add ice to the ridge"; (no-ice frame: coffee to ~4th line, not captured in text)
  - All 5 ✓; CONTINUE
- Iced Coffee hub: Brew ✓ Build ✓ Modifications ✓ CONTINUE (an "Iced Coffee LTOs" title slide appeared briefly: Monin French Vanilla and other syrups)
- Cold Brew hub: "Learn all there is to know about Cold Brew by selecting each item below." Brew / Build / Modifications
  - "You may have guessed by the name - Cold Brew is brewed cold. What exactly does that mean?" / "It is steeped in cold water for 16 hours, which creates a smoother, more concentrated coffee flavour, compared to Iced Coffee." CONTINUE
  - "You can brew a small or large batch of Cold Brew. Select each step in order to learn how." 1. Position Toddy Pail / 2. Add Cold Brew Grinds / 3. Add Water / 4. Mix & Store / 5. Add More Water & Transfer / 6. Leftover Cold Brew?
    - 1: "Position Toddy Pail" (pail + base); "Cold Brew filter over sides of pail"
    - 2: "Add Cold Brew grinds"; "Small batch = 2 pouches | Large batch = 4 pouches"
    - 3: "Graduated cylinder | Add cold or room temperature filtered water"; "Single batch: 192 oz water / Double batch: 384 oz water"; pail marks "Large Batch: Steeping Fill Line" / "Small Batch: Steeping Fill Line" (LARGE BATCH 1. Steeping / 2. Total; SMALL BATCH 1. Steeping / 2. Total)
    - 4: "Carefully mix with fondant spoon"; "Place a Lid"; "Add Daymark label | 16-hour steep time"; "Set a timer or place reminder at POS" (14 hours / 7 hours; note "Cold Brew Steeping until 4pm"); "Store Toddy Pail at room temperature in BOH"
    - 5: (timer icon) "Dispense Cold Brew into second Toddy Pail"; "Add more filtered water" (to "Large Batch: Total" / "Small Batch: Total" lines); "Transfer Cold Brew to Slimline"
    - 6: Toddy pail on rack; walk-in fridge; "48 hour shelf life"; Toddy pail vs Slimline labelled "Cold Brew"
    - All 6 ✓; CONTINUE

## 5. Quizzes and assessments

### 5.1 Hot Beverages - Speciality Tea — knowledge checks

| # | Question | Choices | Picked | Result |
|---|---|---|---|---|
| 1 | Sort these Specialty Teas by tea type. Drag each package to the correct category, then select Submit. | Peppermint / Earl Grey / Green Tea -> Black Tea / Green Tea / Herbal Tea | Earl Grey -> Black Tea; Green Tea -> Green Tea; Peppermint -> Herbal Tea | Correct ("That's right! You selected the correct response.") |
| 2 | Guest: "I'd like to order a tea, but I'm looking for something caffeine-free. What do you recommend?" How should you respond? | "My favourite is Green Tea! Would you like to try one?" / "Our Herbal Teas have little to no caffeine. Would you like to try a Peppermint Tea?" | Herbal Teas / Peppermint | Correct ("That's right! You selected the correct response.") |
| 3 | Your Guest ordered an Extra-Large Peppermint Tea. How many tea bags do you add to the cup? | One Tea Bag / Two Tea Bags | Two Tea Bags | Correct |
| 4 | What does it mean when a Specialty Tea is ordered "Bag Out"? | Dunk the tea bag in the hot water until the colour begins to change and discard before serving / Serve the Guest a cup of hot water with a sleeve and an unopened tea bag package / Leave the tea bag to steep in the hot water when you serve it to the Guest | Dunk ... discard before serving | Correct |

### 5.2 Hot Beverages - Speciality Tea — feedback survey (answered per the CLAUDE.md feedback rule)

| # | Question | Choices | Picked / written |
|---|---|---|---|
| 1 | Did the video clearly teach the new procedures? | Agree / Disagree | Agree (clicking advanced automatically) |
| 2 | Was the video engaging and visually effective? | Agree / Disagree | Agree |
| 3 | Was the video length appropriate? | Agree / Disagree | Agree |
| 4 | OPTIONAL QUESTION Do you have any other feedback or concerns about this training? If yes, please write it below. If you don't have any, you can Continue. (text box "type your text here"; SUBMIT / CONTINUE) | free text | Left empty; clicked CONTINUE (skipped) |

Course result: completed 09/22/2026 07:31 pm, final grade 100.

### 5.3 Hot Beverages - French Vanilla and Hot Chocolate — knowledge checks

| # | Question | Choices | Picked | Result |
|---|---|---|---|---|
| 1 | "Your Guest ordered a Small French Vanilla. Start by placing a Small Hot Beverage cup under the French Vanilla spout. Now, what button do you press?" (BUNN panel: + / S/P / M/M / L/G / XL/TG for French Vanilla, Hot Chocolate, White Hot Chocolate) | French Vanilla S/P | Correct (moved to next step: "Great job!") |
| 2 | "Your Guest ordered a Small French Vanilla. Great job! What's the next step?" | Add Lid / Stir / Add Sleeve | Add Lid | Correct ("That's right!") |
| 3 | "Your Guest ordered a Small French Vanilla. That's right! What do you mark the lid with?" (text box "< Type your answer here.") | (text) | FV | Correct ("You got it! This Small French Vanilla is ready to serve to your Guest.") |
| 4 | "What is a Coffee Mocha?" | ½ French Vanilla, ½ Hot Chocolate / ¾ Hot Chocolate, ¼ Original Blend / Chocolate Syrup, Original Blend Coffee / ½ Original Blend, ½ Hot Chocolate | ½ Original Blend, ½ Hot Chocolate | Correct ("That's right! You selected the correct response.") |

### 5.4 Hot Beverages - French Vanilla and Hot Chocolate — feedback survey (answered per the CLAUDE.md feedback rule)

| # | Question | Choices | Picked / written |
|---|---|---|---|
| 1 | Did the video clearly teach the new procedures? | Agree / Disagree | Agree |
| 2 | Was the video engaging and visually effective? | Agree / Disagree | Agree |
| 3 | Was the video length appropriate? | Agree / Disagree | Agree |
| 4 | OPTIONAL QUESTION Do you have any other feedback or concerns about this training? If yes, please write it below. If you don't have any, you can Continue. (text box "type your text here"; SUBMIT / CONTINUE) | free text | Left empty; clicked CONTINUE (skipped) |

Course result: completed 09/22/2026 07:43:11 pm, final grade 100.

### 5.5 Cold Beverages 1 - Frozen Beverages — knowledge checks (in progress)

| # | Question | Choices | Picked | Result |
|---|---|---|---|---|
| 1 | How many pumps of Syrup does each size of Cold Beverage receive? Drag the correct number of pumps to the correct cup, then select Submit. | 2 / 3 / 4 pumps -> Small / Medium / Large cups | Intended 2->Small, 3->Medium, 4->Large (per "It's always... 2 pumps for a Small / 3 for a Medium / 4 for a Large"); drags would not register | Not answered — "Invalid Answer: You must complete the question before submitting." |

| 1 (retry by user) | How many pumps of Syrup does each size of Cold Beverage receive? (drag and drop) | 2 / 3 / 4 -> Small / Medium / Large | Answered by the user by hand (Claude's drags wouldn't register) | Not seen by Claude |
| 2 | What temperature must prepared Java Mix or Neutral Base be before it's added to the Frozen Beverage Machine? | 40 / 45 / 50 / 55 (thermometer readings, °F) | 40 | Correct ("That's right! You selected the correct response.") |
| 3 | What happens if you do not wait 7 minutes for the Java Mix or Neutral Base to fully freeze in the Frozen Beverage Machine before serving? | Frozen Beverages will be runny and the portion size will be off / Frozen Beverages will be airy / Frozen Beverages will be too thick and the portion size will be off / Frozen Beverages will be icy | Runny and the portion size will be off | Correct ("That's right! You selected the correct response.") |
| 4a | Small Iced Capp — step: Cup Size -> "Select the correct sized cup." | Small / Medium / Large | Small | Correct ("That's Correct — You selected the correct choice.") |
| 4b | Step: Dairy -> "Use the Dairy Machine to dispense the correct amount of dairy." | SureShot buttons | Attempt 1: CAPP (red) + ICED CAPP + Cream S/P -> Incorrect; attempt 2: ICED CAPP + Cream S/P (red CAPP toggled off) | Correct on attempt 2 |
| 4c | Next step after Dairy | Frozen Beverage Machine / Lid / Whip | Attempt 1: Frozen Beverage Machine -> "That's Incorrect"; attempt 2: Lid | Correct on attempt 2 |
| 4d | Step: Lid -> "Select the correct lid type." | Flat Lid (Hot) / Dome Lid / Flat Lid (Cold) | Dome Lid | Correct |
| 4e | Step: Frozen Beverage Machine -> "Next, with the dome lid on top, add Java Mix. What fill line do you add Java Mix to so that there is a soft peak on top?" | 1st / 2nd / 3rd / 4th / 5th fill line | 4th fill line | Correct |
| 4f | Step: Whip -> "Whip for 15 seconds. Will the green light be on or off once 15 seconds has passed? Green light will be:" | ON / OFF | OFF | Correct |
| 5 | Large Frozen Lemonade — "Start by adding Lemon Syrup to a Large cup. How many pumps do you add?" | Pump interaction (bottle + cup) | Intended 4 pumps (Large = 4). Clicked bottle pump 4x -> Submit -> "Invalid Answer: You must complete the question before submitting."; one drag bottle->cup: no effect | Not answered — waiting on user (drag interaction) |

| 5 (cont.) | Large Frozen Lemonade — lemon syrup pumps | pump | Done by the user by hand | Not seen by Claude |
| 6 | Great! Place a dome lid on top. Do you add Java Mix or Neutral Base? | Add Neutral Base / Add Java Mix | Add Neutral Base | Accepted (moved to next step) |
| 7 | Perfect! Time to whip. How many seconds do you whip for? | 10 / 20 / 15 / 25 seconds | 15 seconds | Accepted (moved to next slide) |

### 5.6 Cold Beverages 1 - Frozen Beverages — feedback survey (answered per the CLAUDE.md feedback rule)

| # | Question | Choices | Picked / written |
|---|---|---|---|
| 1 | Did the video clearly teach the new procedures? | Agree / Disagree | Agree |
| 2 | Was the video engaging and visually effective? (assumed; the question advanced without a clear screenshot) | Agree / Disagree | Agree |
| 3 | Was the video length appropriate? | Agree / Disagree | Agree |
| 4 | OPTIONAL QUESTION Do you have any other feedback or concerns about this training? If yes, please write it below. If you don't have any, you can Continue. | free text | Left empty; clicked CONTINUE (skipped) |

Course result: Cold Beverages 1 - Frozen Beverages completed (plan page shows "Course completed").

### 5.7 Cold Beverages 2 - Iced Coffee, Cold Brew and Iced Chai Latte — knowledge checks (in progress)

| # | Question | Choices | Picked | Result |
|---|---|---|---|---|
| 1 | "You've brewed 3 pots of Iced Coffee. Complete the rest of the steps to get it ready to serve. Start by transferring the Iced Coffee. Select the correct container." | Slimline / Toddy Pail | Slimline | Correct ("That's right! You selected the correct response.") |
| 2 | "Great job! Now, add a Daymark label, place the lid on top, and move the Slimline into the walk-in fridge to chill. What temperature must Iced Coffee reach?" | 80 / 85 / 90 / 95 (°F thermometers) | 80 | Correct ("Perfect! Now that the Iced Coffee is properly chilled, move it to the counter and serve.") |
| 3 | Medium Original Iced Coffee (marker 1): What size cup do you use? | Small / Medium / Large | Medium | Correct |
| 4 | (marker 2) How many pumps of syrup do you add? (Cane Sugar pump — click the pump top) | pump count | 3 pumps | Correct |
| 5 | (marker 3) What buttons do you press to dispense the correct amount of Cream? | SureShot panel | ICED COFFEE + Cream M | Correct |
| 6 | (marker 4) How much Iced Coffee do you dispense? | 1st / 2nd / 3rd fill line | 3rd fill line | Correct |
| 7 | (marker 5) Do you need to stir? | YES / NO | YES | Correct |
| 8 | (marker 6) How much ice do you add? | 5th Line / Below Rim / To the Rim | To the Rim | Correct |
| 9 | (marker 7) Select the correct lid type. | Flat Lid (Hot) / Dome Lid / Flat Lid (Cold) | Flat Lid (Cold) | Correct ("Nice job! Now serve to your Guest.") |
| 10 | How long exactly must Cold Brew steep for? | 4 / 20 / 16 / 10 hours | 16 hours | Correct ("That's right! You selected the correct response.") |
| 11 | "Cold Brew has finished steeping and has been transferred to a second Toddy Pail. Drag the remaining steps into the correct order." Rows as shown: Step 1 Transfer the Cold Brew to a Slimline / Step 2 Add filtered water to the "Total Fill Line" / Step 3 Label the Slimline "Cold Brew", add a Daymark label showing a 48-hour shelf life and ensure the Fresh Brewer Screen is on the spout | drag to reorder | Intended: 1 Add filtered water to the "Total Fill Line" / 2 Transfer the Cold Brew to a Slimline / 3 Label the Slimline (per module step 5: add more water, then transfer). Drag did not move rows | Not answered — waiting on user |

## 6. Actions log

_Note: times from 19:23 onward are estimates and ran ahead of the real clock; `date` read 19:31:58 right after the course page showed completion at 07:31 pm. Order of actions is accurate._

| Time (EDT, ~approximate) | Action |
|---|---|
| 19:22 | Closed entry 4 (end time, status table); created entry 5 |

| 19:23 | JS: visibilityState hidden, hasFocus false; screenshot: player loaded on Intro |
| 19:24 | Clicked CC (hit volume/mute control instead); clicked item 1 (tea packages); Continue |
| 19:25 | Drag-drop sort quiz; Submit -> Correct |
| 19:26 | Scenario answer (Herbal/Peppermint) -> Correct; Continue; hub; clicked Build; Continue; watched build video (CC appeared on) |
| 19:28 | Q3 picked Two Tea Bags; Submit -> Correct |
| 19:29 | Hub -> Ways to Order; clicked Bag In, Bag Out, On the Side (each played) |
| 19:30 | Q4 picked "Dunk ... discard before serving"; Submit -> Correct |
| 19:31 | Hub -> Modifications; Continue; hub -> Available Sizes; Continue; Take 12 video |
| 19:33 | Build Guide video; Outro |
| 19:34 | Survey: Agree x3; optional written feedback skipped (Continue) |
| 19:35 | Congratulations slide |
| 19:36 | Clicked EXIT COURSE; navigated to course 100 page: Completed, grade 100 |
| ~19:33 | Navigated to course 1700; read page text; START LEARNING NOW; Start learning now (player loaded ~10 s); Intro; hub -> Build; Continue x3 |
| ~19:36 | Q1 clicked French Vanilla S/P; Submit -> next step; Q2 Add Lid; Submit; Q3 typed FV; Submit -> Correct |
| ~19:38 | Hub -> Modifications; Continue; Mocha build video (Continue x4; one click on replay control had no visible effect) |
| ~19:40 | Remember / 1/4 HC slides; Continue; Q4 picked ½ Original Blend, ½ Hot Chocolate; Submit -> Correct |
| ~19:42 | Hub -> Seasonal Flavours; Continue; clicked Seasonal Hot Chocolate tab; Continue; hub -> Available Sizes; Continue; Take 12 video |
| ~19:43 | Cambro video; Continue; hub Continue; Outro; survey Agree x3; optional written feedback skipped (Continue); Congratulations; EXIT COURSE |
| ~19:44 | Navigated to course 1700 page: Completed 07:43:11 pm, grade 100 |
| ~19:45 | Navigated to course 101; read page text; START LEARNING NOW (second click opened lesson page); Start learning now -> lightbox |
| ~19:46 | Waited ~50 s: loading spinner. JS: visibilityState "hidden", hasFocus true. Stopped to ask user |
| ~21:19 | User asked to continue on the Steeped Tea lesson URL (under learning plan 469). Navigated there: "Well done! The course is completed." (completed 07:19 pm) — not retaken. JS: visibilityState hidden, hasFocus false |
| ~21:19 | Navigated to /learn/learning-plans/469/beverage; read page text (3 of 8 completed; Cold Beverages 1 In progress) |
| ~21:20 | Clicked RESUME TRAINING -> course 101 (plan URL); RESUME TRAINING -> lesson; Resume training overlay -> lightbox; player loaded ~10 s with "Resume"/"Restart"; clicked Resume |
| 21:21 | Closed "Sizes" popup; hub "Select each item below to go over some Cold Beverage basics." Sizes ✓ / Fill Lines / Syrup / Build Charts |
| 21:23 | Opened Fill Lines, Syrup, Build Charts popups and closed each; hub all ✓ |
| ~21:23 | CONTINUE -> syrup drag-drop quiz. Tried drags 2->Small, 3->Medium, 4->Large (items snapped back); drag from number labels; click-to-place; Tab keyboard focus (went to "Back to top", then Play button); pressed Play (slide timeline was paused); two more drags — none placed |
| ~21:24 | Clicked SUBMIT with nothing placed -> in-player "Invalid Answer / You must complete the question before submitting." OK |
| 21:25 | find/read_page: page behind player shows "Session expired / Your session has expired. Please log in again to continue your training from where you left off." with "Log in" button. Stopped to ask user |
| ~21:32 | User asked to continue on https://www.trainingattims.com/learn/learning-plans/ (same origin; continued entry 5). Page rendered blank (header only). Navigated to plan 469: Cold Beverages 1 still In progress, 0 of 1 lessons |
| ~21:32 | Opened Cold Beverages 1 lesson; no "Session expired" text in the page any more (user logged in). Resume training -> player Resume -> syrup drag-drop slide |
| 21:32 | Two more drags (2 drops -> Small cup body, -> Small cup rim): snapped back each time. Stopped to ask the user to answer this question by hand |
| 21:35 | Found player past the syrup quiz (user answered it by hand). Mixture steps 1–5 clicked in order; all ✓ |
| 21:36 | CONTINUE -> temperature question: picked 40; Submit -> Correct; Continue -> 7-minute question: picked runny/portion off; Submit -> Correct |
| 21:38 | Iced Capp build: clicked Cream, Dome lid and Java Mix, Whip (bottom to top); all ✓ |
| 21:41 | Small Iced Capp activity: Cup Size->Small ✓; Dairy (1 wrong, then ICED CAPP + Cream S/P ✓); FBM too early ✗; Lid->Dome ✓; FBM->4th fill line ✓; Whip->OFF ✓ |
| 21:43 | Continue; hub -> Modifications video (watched twice to catch skipped frames) |
| 21:45 | Hub -> Available Flavours video; LTOs video; all 3 ✓ |
| 21:46 | Hub CONTINUE -> Frozen Lemonade video -> pump activity. Clicked pump 4x; Submit -> Invalid Answer; OK; drag bottle to cup: no effect. Stopped to ask user |
| 22:04 | Found Frozen Lemonade activity past the pump step (user). Neutral Base; Submit; 15 seconds; Submit; portioning tips slide |
| 22:06 | Rinse slide; recap; survey (Agree x3 — radio didn't show as filled but survey advanced; one Submit with nothing selected -> Invalid Answer, OK, Agree, Submit); optional feedback skipped (Continue); Congratulations; EXIT COURSE; plan page: Cold Beverages 1 Completed, 4 of 8 |
| ~21:57 | Plan page -> Cold Beverages 2 course (1766); read page text; START LEARNING NOW -> lesson; Start learning now -> player loaded |
| 22:10 | Hub -> Brew; steps 1–5 in order; all ✓ |
| 22:11 | Brew activity: Slimline -> Correct; 80°F -> Correct |
| 22:13 | Hub -> Build; clicked Cane Sugar Syrup, Cream, Iced Coffee and stir, Ice; all ✓ |
| 22:16 | Strawless/dome lid reminders; virtual station markers 1–7, all Correct (pump works by clicking the pump top) |
| 22:20 | Modifications hub: Black, Sweetness, Flavoured, Substituting Dairy, Ice; all ✓ |
| 22:25 | Iced Coffee hub Continue; Cold Brew hub -> Brew; intro; steps 1–6 in order; all ✓ |
| 22:26 | Q10 16 hours -> Correct; Q11 drag-to-order: one drag (row 2 -> row 1) did not reorder; Reset/Submit appeared. Stopped to ask user |
| (2026-09-23) | User asked to continue; screenshot: Cold Brew drag-to-order slide still in original order (Transfer / Add water / Label), Reset + Submit visible; window resized (1512x724) |
| (2026-09-23) 02:03 | Claude's usage limit reset; retried drag (row 2 -> row 1) at new coordinates -> "Browser extension is not connected"; tabs_context_mcp same error. Stopped to ask user |

## 7. Network and API data

## 8. Console output

## 9. Errors and blockers

- User asked at ~21:19 to continue on the Steeped Tea lesson URL (https://www.trainingattims.com/learn/learning-plans/469/beverage/courses/1699/hot-beverages-steeped-tea/lessons/12249:1511/hot-beverages-steeped-tea). Same origin as the root URL, so this was treated as a continuation of entry 5, not a new root. Steeped Tea already completed (07:19 pm); not retaken.
- RESOLVED (user logged in): LOGIN. Behind the Cold Beverages 1 player, the page shows "Session expired — Your session has expired. Please log in again to continue your training from where you left off." (Log in button). The syrup drag-and-drop quiz won't accept drags, possibly because of the expired session. Claude does not log in; the user needs to log in in Chrome.

- The page reported `document.visibilityState = "hidden"` at session start (19:23), yet the Speciality Tea and French Vanilla/Hot Chocolate players loaded and completed normally, so a hidden tab alone doesn't always stop the player.
- BLOCKED (waiting on user): Cold Beverages 1 - Frozen Beverages SCORM player stuck on a loading spinner for ~50 s (page visibilityState "hidden"). Same symptom as entries 3–4, which cleared once the user returned to the browser.
- RESOLVED (user answered by hand): the Cold Beverages 1 syrup drag-and-drop question ("How many pumps of Syrup does each size of Cold Beverage receive?") won't take drags from Claude's browser tool even after the user logged in (8+ attempts in total: drops, number labels, cup body and rim, click-to-place, keyboard). The drag-and-drop in Speciality Tea worked, so this slide likely needs real pointer movement. Asked the user to place 2 -> Small, 3 -> Medium, 4 -> Large and press Submit by hand.
- RESOLVED (user did it by hand): Cold Beverages 1 Large Frozen Lemonade pump activity ("How many pumps do you add?") doesn't register Claude's clicks or drag. Answer per the module: 4 pumps for a Large. Asked the user to do it by hand.
- BLOCKED (waiting on user): Cold Beverages 2 Cold Brew drag-to-order question. Claude's drag doesn't reorder the rows. Correct order per the module: 1 Add filtered water to the "Total Fill Line", 2 Transfer the Cold Brew to a Slimline, 3 Label the Slimline. Asked the user to reorder by hand and Submit.
- BLOCKED (waiting on user): the Claude in Chrome extension disconnected (2026-09-23). The Cold Brew drag-to-order question is still unanswered (order unchanged on the last screenshot).

